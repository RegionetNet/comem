﻿//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ConEmuDw.rc
//
#ifndef IDC_STATIC
#define IDC_STATIC                     -1
#endif
#define IDD_COLORS                      101
#define IDC_TEXT                        1001
#define IDC_FORE                        1002
#define IDC_BACK                        1003
#define IDC_FORE_TRANS                  1004
#define IDC_BACK_TRANS                  1005
#define IDC_BOLD                        1006
#define IDC_ITALIC                      1007
#define IDC_UNDERLINE                   1008
#define IDC_FORE_4BIT                   1009
#define IDC_BACK_4BIT                   1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
