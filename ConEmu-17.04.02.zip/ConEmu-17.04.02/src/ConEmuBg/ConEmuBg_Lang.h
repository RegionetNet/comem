﻿
#pragma once

enum {
	CEPluginName=0,
	CEPluginEnable,
	CEPathLabel,
	CEMonitorFileChange,
	CEBtnOK,
	CEBtnCancel,
	};
