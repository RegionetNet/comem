#pragma once

#define CEVS_STABLE   0
#define CEVS_PREVIEW  1
#define CEVS_ALPHA    2

#define ConEmuVersionStage CEVS_PREVIEW
