// 170402
#define MVV_1 17
#define MVV_2 4
#define MVV_3 2
#define MVV_4 0
#define MVV_4a ""
#undef MVV_git

#include "version_stage.h"
#include "version_macro.h"
