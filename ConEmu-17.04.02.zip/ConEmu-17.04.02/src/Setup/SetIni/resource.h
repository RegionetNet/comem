﻿#define IDI_ICON1                       1
