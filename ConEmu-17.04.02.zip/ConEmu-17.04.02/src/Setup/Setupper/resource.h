// This file is used in *.rc!
// Don't convert it to UTF-8
#define IDI_ICON1                       1
#define Ver86 101
#define Ver64 102
#define CABFILE 103
#define EXEFILE 104
