#define CONEMUVERN 17,4,2,0
#define CONEMUVERS "170402"
#define CONEMUVERL L"170402"
#define MSI86 "../ConEmu.170402.x86.msi"
#define MSI64 "../ConEmu.170402.x64.msi"
