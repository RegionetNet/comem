// This file is used in *.rc!
// Don't convert it to UTF-8
#define IDI_ICON1                       1
