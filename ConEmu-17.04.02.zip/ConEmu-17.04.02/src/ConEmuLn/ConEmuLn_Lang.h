
#pragma once

enum {
	CEPluginName=0,
	CEPluginEnable,
	CEColorPanelLabel,
	CEColorEditorLabel,
	CEColorViewerLabel,
	CEColorType,
	CEColorTypeLines,
	CEColorTypeStripes,
	CEHilightPlugins,
	CEPluginColor,
	CEBtnOK,
	CEBtnCancel,
	};
